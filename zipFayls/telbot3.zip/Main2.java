import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import model.Response;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.lang.reflect.Type;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

public class Main2 {
    public static void main(String[] args) throws IOException {
        XSSFWorkbook workbook = new XSSFWorkbook();
        FileOutputStream stream = new FileOutputStream("D:\\IT PROGRAM\\TelegramBots3\\src\\main\\resources\\model\\workbook3.xlsx");
        XSSFSheet sheet = workbook.createSheet();
        XSSFRow row = sheet.createRow(0);
        row.createCell(0).setCellValue("Name");
        row.createCell(1).setCellValue("DrugId");
        row.createCell(2).setCellValue("InternationalName");
        row.createCell(3).setCellValue("Information about drugs");
        char a = 'А';
        char b = 'Я';
        int c = (int) b - (int) a;
        for (int i = 0; i <= c; i++) {
            String x = String.valueOf((char) (((int) a) + i));
            String encodeCiril = URLEncoder.encode(x, "UTF-8");
            URL url = new URL("https://apptechka.uz/api/client/Drug/GetDrugsByLetter?name=" +
                    encodeCiril + "&filter=%7B%22sort%22:%5B%5D,%22skip%22:0,%22take%22:10000,%22filter%22:%7B%22logic%22:%22and%22,%22filters%22:%5B%5D%7D%7D");
            URLConnection connection = url.openConnection();
            Gson gson = new Gson();
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            Type type = new TypeToken<Response>() {
            }.getType();
            Response tabletka = gson.fromJson(reader, type);
            for (int j = 0; j < tabletka.getData().size(); j++) {
                row = sheet.createRow(j + 1);
                row.createCell(0).setCellValue(tabletka.getData().get(j).getName());
                row.createCell(1).setCellValue(tabletka.getData().get(j).getDrugId());
                row.createCell(2).setCellValue(tabletka.getData().get(0).getInternationalName());
                row.createCell(3).setCellValue("https://apptechka.uz/medicine/" + tabletka.getData().get(0).getDrugId());

            }
            workbook.write(stream);
            stream.close();
            System.out.println("success");
        }
        }
    }

