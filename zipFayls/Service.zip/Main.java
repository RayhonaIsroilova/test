package uz.pdp.RegionApp;
import uz.pdp.RegionApp.Service.RepublicImpl;
import uz.pdp.RegionApp.model.*;

import java.util.Scanner;
public class Main {
    public static Khokim[] khokims = new Khokim[100];
    public static District[] districts = new District[100];
    public static Region[] regions = new Region[14];
    public static President[] presidents = new  President[5];
    static Scanner scanner = new Scanner(System.in);


    public static void main(String[] args) {
        System.out.println("Please enter your name!");
        String name = scanner.nextLine();
        System.out.println("Please enter your surname!");
        String surname = scanner.nextLine();
        System.out.println("Welcome " + name + surname + " to application about informations of republic!");
        System.out.println("Please choose the republics");
        int id = scanner.nextInt();
        switch (id) {
            case 1:
            Republic republics = new  Republic();
            //getRepublic Listdagi 0-index malumotlari regionlari ro'yxati chiqadi
                            //viloyat
                break;
            case 3:
                            System.out.println("qaysi Viloyat malumoti kk!");
                            int vId = scanner.nextInt();
                            switch (vId) {
                                case 1:
                                    //getRegions listdagi 0- indexdagi tumanlari ro'yxati
                                    System.out.println("qaysi Tuman malumoti kk!");
                                    int tId = scanner.nextInt();
                                    //tuman malumotlari hokimi
                                    break;
                            }
                            break;
                    }
            }

        }




