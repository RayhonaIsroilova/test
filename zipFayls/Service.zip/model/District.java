package uz.pdp.RegionApp.model;


import uz.pdp.RegionApp.model.template.Area;

public class District extends Area {

        //    private int year; //23 45 int
        private String khokim;

        public District(String areaName, double areaSize, long areaPopulation, Khokim khokim) {
            super(areaName, areaSize, areaPopulation);
            this.khokim = String.valueOf(khokim);
        }

        public District() {
        }

        public String getKhokim() {
            return khokim;
        }

        public void setKhokim(String khokim) {
            this.khokim = khokim;
        }

        @Override
        public void printInfo() {
            super.printInfo();
        }

        @Override
        public String toString() {
            return "District{" +
                    "khokim=" + khokim +
                    "} " + super.toString();
        }

    @Override
    public String getName() {
        return null;
    }

}


