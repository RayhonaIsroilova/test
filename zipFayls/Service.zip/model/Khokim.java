package uz.pdp.RegionApp.model;

import uz.pdp.RegionApp.model.template.Person;

public class Khokim extends Person {


        private int id;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        private int yearsActive; //7 yilga saylanish

        public void printJob(int years) {
            System.out.println("Bu hokim " + years + "yildan beri ishlaydi");
        }

        @Override
        public void printInfo() {
            System.out.println("Lavozimi : Khokim");
            super.printInfo();
        }

        public Khokim(int id, String name, String surName, String address, int yearsActive) {
            super(name, surName, address);
            this.id = id;
            this.yearsActive = yearsActive;
        }

        public Khokim() {
        }

        public int getYearsActive() {
            return yearsActive;
        }

        public void setYearsActive(int yearsActive) {
            this.yearsActive = yearsActive;
        }

        @Override
        public String toString() {
            return "Khokim{" +
                    "id=" + id +
                    ", yearsActive=" + yearsActive +
                    "} " + super.toString();
        }
    }


