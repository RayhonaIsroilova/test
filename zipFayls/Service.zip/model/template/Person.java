package uz.pdp.RegionApp.model.template;


    public abstract class Person {
        private String name, surName, address;

        public void printInfo() {
            System.out.println("Person ma'lumotlari :  ");
            System.out.println("Name : " + this.name);
            System.out.println("SurName : " + this.surName);
            System.out.println("Address : " + this.address);
        }

        public Person(String name, String surName, String address) {
            this.name = name;
            this.surName = surName;
            this.address = address;
        }

        public Person() {
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getSurName() {
            return surName;
        }

        public void setSurName(String surName) {
            this.surName = surName;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        @Override
        public String toString() {
            return "Person{" +
                    "name='" + name + '\'' +
                    ", surName='" + surName + '\'' +
                    ", address='" + address + '\'' +
                    '}';
        }

        public abstract void setYearsActive(int nextInt);
    }


