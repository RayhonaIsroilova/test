package uz.pdp.RegionApp.model.template;


    public abstract class Area {
        private String areaName;
        private double areaSize;
        private long areaPopulation;

        public void printInfo() {
            System.out.println("Area ");
            System.out.println("Name : " + this.areaName);
            System.out.println("Population : " + this.areaPopulation);
            System.out.println("Size : " + this.areaSize);
        }

        public Area(String areaName, double areaSize, long areaPopulation) {
            this.areaName = areaName;
            this.areaSize = areaSize;
            this.areaPopulation = areaPopulation;
        }

        public Area() {
        }

        @Override
        public String toString() {
            return "Area{" +
                    "areaName='" + areaName + '\'' +
                    ", areaSize=" + areaSize +
                    ", areaPopulation=" + areaPopulation +
                    '}';
        }

        public String getAreaName() {
            return areaName;
        }

        public void setAreaName(String areaName) {
            this.areaName = areaName;
        }

        public double getAreaSize() {
            return areaSize;
        }

        public void setAreaSize(double areaSize) {
            this.areaSize = areaSize;
        }

        public long getAreaPopulation() {
            return areaPopulation;
        }

        public void setAreaPopulation(long areaPopulation) {
            this.areaPopulation = areaPopulation;
        }

        public abstract String getName();
    }


