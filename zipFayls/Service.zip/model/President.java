package uz.pdp.RegionApp.model;


import uz.pdp.RegionApp.model.template.Person;

public class President extends Person {
        private int yearsActive; //7 yilga saylanish

        public void printJob(int years) {
            System.out.println("Bu president " + years + "yildan beri ishlaydi");
        }

        @Override
        public void printInfo() {
            System.out.println("Lavozimi : President");
            super.printInfo();
        }

        public President(String name, String surName, String address, int yearsActive) {
            super(name, surName, address);
            this.yearsActive = yearsActive;
        }

        public President() {
        }

    @Override
    public void setYearsActive(int nextInt) {

    }

}


