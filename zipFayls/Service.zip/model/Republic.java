package uz.pdp.RegionApp.model;


import uz.pdp.RegionApp.model.template.Area;

public class Republic extends Area {
        private President president;
        private Region[] regions;

        public Republic(String areaName, double areaSize, long areaPopulation, President president, Region[] regions) {
            super(areaName, areaSize, areaPopulation);
            this.president = president;
            this.regions = regions;
        }

        public Republic(String areaName, double areaSize, long areaPopulation, President president) {
            super(areaName, areaSize, areaPopulation);
            this.president = president;
        }

    public Republic() {

    }

    @Override
    public String getName() {
        return null;
    }

    public President getPresident() {
            return president;
        }

        public void setPresident(President president) {
            this.president = president;
        }

        public Region[] getRegions() {
            return regions;
        }

        public void setRegions(Region[] regions) {
            this.regions = regions;
        }

        @Override
        public void printInfo() {
            super.printInfo();
        }
    }


