package uz.pdp.RegionApp.model;



import uz.pdp.RegionApp.model.template.Area;

import java.util.Arrays;

    public class Region extends Area { //bitta tumanni
        private Khokim khokim; //composition
        private District[] districts;

        public Khokim getKhokim() {
            return khokim;
        }

        public void setKhokim(Khokim khokim) {
            this.khokim = khokim;
        }

        public District[] getDistricts() {
            return districts;
        }

        public void setDistricts(District[] districts) {
            this.districts = districts;
        }

        public Region(String areaName, double areaSize, long areaPopulation, Khokim khokim, District[] districts) {
            super(areaName, areaSize, areaPopulation);
            this.khokim = khokim;
            this.districts = districts;
        }

        public Region(String areaName, double areaSize, long areaPopulation, Khokim khokim) {
            super(areaName, areaSize, areaPopulation);
            this.khokim = khokim;
        }

        public Region() {
        }

        @Override
        public void printInfo() {
            super.printInfo();
        }

        @Override
        public String toString() {
            return "Region{" +
                    "khokim=" + khokim +
                    ", districts=" + Arrays.toString(districts) +
                    "} " + super.toString();
        }

        @Override
        public String getName() {
            return null;
        }
    }


