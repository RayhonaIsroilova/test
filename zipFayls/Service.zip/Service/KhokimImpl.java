package uz.pdp.RegionApp.Service;
import java.util.Scanner;
public class KhokimImpl implements Service {
    //CRUD Sistema=>CREATE READ UPDATE DELETE
    static Khokim[] khokims = new Khokim[100];
    Scanner scanner = new Scanner(System.in);

    @Override
    public void add() {
        System.out.println("Hokim qo'shish : ");
        Khokim khokim = new Khokim();//mana

        System.out.println("Enter name : ");
        khokim.setName(scanner.nextLine());

        System.out.println("Enter surName : ");
        khokim.setSurName(scanner.nextLine());

        System.out.println("Enter address : ");
        khokim.setAddress(scanner.nextLine());
        scanner = new Scanner(System.in);

        System.out.println("Enter yearsActive : ");
        khokim.setYearsActive(scanner.nextInt());

        System.out.println("Saved Success!");
        System.out.println(khokim);

        for (int i = 0; i < khokims.length; i++) {
            if (khokims[i] == null) {
                khokims[i] = khokim;
                break;
            }
        }
        System.out.println("yana qo'shashishzmi? Ha=> 1 Yo'q=> 0");
    }

    @Override
    public void edit() {
        System.out.println("Qaysi hokimni o'zgartirmoqchisiz?");
        //list
        getList();
        int id = scanner.nextInt();
        Khokim edit = khokims[id - 1]; //hokim topib olindi!
        System.out.println("Edit Name ");
        edit.setName(scanner.nextLine());

        System.out.println("Edit SurName ");
        edit.setSurName(scanner.nextLine());

        System.out.println("Edit Address ");
        edit.setAddress(scanner.nextLine());

        System.out.println("Edit Year ");
        scanner = new Scanner(System.in);
        edit.setYearsActive(scanner.nextInt());

        System.out.println("Edit Success!");

//        khokims[id - 1] = edit;
        //tekshirib ko'raszlar!
    }

    @Override
    public void delete() {
        System.out.println("Qaysi hokimni o'zgartirmoqchisiz?");
        //list
        getList(); //ro'yxat
        int id = scanner.nextInt(); //id 2
        khokims[id - 1] = null; //hokim topib olindi!
        System.out.println("Delete Success!");
    }

    @Override
    public void getOne(String name) {//Ja'far
        boolean empty = true;
        for (int i = 0; i < khokims.length; i++) {
            if (khokims[i] != null && khokims[i].getName().equalsIgnoreCase(name)) { //100%
                empty = false;
                System.out.println((i + 1) + " => " + khokims[i]);
            }
        }
        if (empty) {
            System.out.println("Hokimlar mavjud emas!");
        }
    }

    @Override
    public void getList() {
        System.out.println("Hokimlar ro'yxati! ");
        boolean empty = true;
        for (int i = 0; i < khokims.length; i++) {
            if (khokims[i] != null) {
                empty = false;
                System.out.println((i + 1) + " => " + khokims[i]);
            }
        }
        if (empty) {
            System.out.println("Hokimlar mavjud emas!");
        }
    }
}
