package uz.pdp.RegionApp.Service;

public class Khokim {
    public void setName(String nextLine) {
    }

    public void setSurName(String nextLine) {
    }

    public void setAddress(String nextLine) {
    }

    public void setYearsActive(int nextInt) {
    }

    public String getName() {
        return "";
    }
}
