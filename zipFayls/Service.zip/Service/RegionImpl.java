package uz.pdp.RegionApp.Service;
import uz.pdp.RegionApp.model.Region;
import java.util.Scanner;
public class RegionImpl implements Service {
     static Region[] regions = new Region[14];
     Scanner scanner = new Scanner(System.in);
    @Override
    public void add() {
        Region region = new Region();
        System.out.println("The list of adding Regions : ");

        System.out.print("Please enter new Region name : ");
        region.setAreaName(scanner.nextLine());

        System.out.print("Please enter new Region area size : ");
        region.setAreaSize(scanner.nextDouble());

        System.out.print("Please enter new Region area population : ");
        region.setAreaPopulation(scanner.nextLong());

        for (int i = 0; i < regions.length; i++) {
            if (regions[i] == null) {
                regions[i] = region;
                break;
            }
        }
        System.out.println("The district added successfully!");
    }

    @Override
    public void edit() {
        System.out.println("Which region you want to change : ");
        //list
        int id = scanner.nextInt();
        if (regions.length >= id && regions[id - 1] != null) {
            System.out.println("Please enter edit name : ");
            regions[id - 1].setAreaName(scanner.nextLine());

            System.out.println("Please enter edit area size : ");
            regions[id - 1].setAreaSize(scanner.nextDouble());

            System.out.println("Please enter edit area population ");
            regions[id - 1].setAreaPopulation(scanner.nextLong());
            System.out.println(" The information of region edit successfully!");
        }else {
            System.out.println("Please try again!");
        }

    }

    @Override
    public void delete() {
        System.out.println("Which region you want to delete");
        //list
        getList();
        int id = scanner.nextInt();
        regions[id-1] = null;
        System.out.println("The region delete successfully!");
    }

    @Override
    public void getOne(String name) {
        boolean empty = true;
        for (int i = 0; i < regions.length; i++) {
            if (regions[i] != null && regions[i].getName().equalsIgnoreCase(name)) { //100%
                empty = false;
                System.out.println((i + 1) + " => " + regions[i]);
            }
        }
        if (empty) {
            System.out.println("There is not regions!");
        }
    }

    @Override
    public void getList() {
        System.out.println("The list of regions! ");
        boolean empty = true;
        for (int i = 0; i < regions.length; i++) {
            if (regions[i] != null) {
                empty = false;
                System.out.println((i + 1) + " => " + regions[i]);
            }
        }
        if (empty) {
            System.out.println("There is not regions!");
        }
    }
}
