package uz.pdp.RegionApp.Service;
import uz.pdp.RegionApp.model.President;
import java.util.Scanner;
public class PresidentImpl implements Service {
    static President[] presidents = new  President[5];
    Scanner scanner = new Scanner(System.in);
    @Override
    public void add() {
        System.out.println("Adding President : ");
        President president = new President();//mana

        System.out.println("Enter name : ");
        president.setName(scanner.nextLine());

        System.out.println("Enter surName : ");
        president.setSurName(scanner.nextLine());

        System.out.println("Enter address : ");
        president.setAddress(scanner.nextLine());
        scanner = new Scanner(System.in);

        System.out.println("Enter yearsActive : ");
        president.setYearsActive(scanner.nextInt());

        System.out.println("Saved Success!");
        System.out.println(president);

        for (int i = 0; i < presidents.length; i++) {
            if (presidents[i] == null) {
                presidents[i] = president;
                break;
            }
        }
        System.out.println("yana qo'shashishzmi? Ha=> 1 Yo'q=> 0");
    }

    @Override
    public void edit() {
        System.out.println("Which president you want to change?");
        //list
        getList();
        int id = scanner.nextInt();
        //hokim topib olindi!
       if (presidents.length >= id && presidents[id - 1] != null)
        System.out.println("Edit Name ");
        presidents[id-1].setName(scanner.nextLine());

        System.out.println("Edit SurName ");
        presidents[id-1].setSurName(scanner.nextLine());

        System.out.println("Edit Address ");
        presidents[id-1].setAddress(scanner.nextLine());

        System.out.println("Edit Year ");
        scanner = new Scanner(System.in);
        presidents[id-1].setYearsActive(scanner.nextInt());

        System.out.println("Edit Success!");

//        khokims[id - 1] = edit;
        //tekshirib ko'raszlar!
    }

    @Override
    public void delete() {
        System.out.println("Which president you want to delete");
        //list
        getList();
        int id = scanner.nextInt();
        presidents[id-1] = null;
        System.out.println("The president delete successfully!");
    }

    @Override
    public void getOne(String name) {
        boolean empty = true;
        for (int i = 0; i < presidents.length; i++) {
            if (presidents[i] != null && presidents[i].getName().equalsIgnoreCase(name)) { //100%
                empty = false;
                System.out.println((i + 1) + " => " + presidents[i]);
            }
        }
        if (empty) {
            System.out.println("There is not Presidents!");
        }
    }

    @Override
    public void getList() {
        System.out.println("The list of districts! ");
        boolean empty = true;
        for (int i = 0; i < presidents.length; i++) {
            if (presidents[i] != null) {
                empty = false;
                System.out.println((i + 1) + " => " + presidents[i]);
            }
        }
        if (empty) {
            System.out.println("There is not presidents!");
        }
    }
}
