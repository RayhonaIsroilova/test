package uz.pdp.RegionApp.Service;

public interface Service {

    void add();

    void edit();

    void delete();

    void getOne(String name); //bitta districtni chaqirish

    void getList(); //districtlar ro'yxati

}
