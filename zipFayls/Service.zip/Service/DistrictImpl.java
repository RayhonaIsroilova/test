package uz.pdp.RegionApp.Service;
import uz.pdp.RegionApp.model.District;
import java.util.Scanner;
public class DistrictImpl implements Service {
    static District[] districts = new District[100];
    Scanner scanner = new Scanner(System.in);
    @Override
    public void add() {
        District district = new District();
        System.out.println("District qo'shish oynasi : ");

        System.out.print("Please enter new District name : ");
        district.setAreaName(scanner.nextLine());

        System.out.print("Please enter new District area size : ");
        district.setAreaSize(scanner.nextDouble());

        System.out.print("Please enter new District area population : ");
        district.setAreaPopulation(scanner.nextLong());

        for (int i = 0; i < districts.length; i++) {
            if (districts[i] == null) {
                districts[i] = district;
                break;
            }
        }
        System.out.println("The district added successfully!");
    }

    @Override
    public void edit() {
        System.out.println("Which district you want to change : ");
        //list
        int id = scanner.nextInt();
        if (districts.length >= id && districts[id - 1] != null) {
            System.out.println("Please enter edit name : ");
            districts[id - 1].setAreaName(scanner.nextLine());

            System.out.println("Please enter edit area size : ");
            districts[id - 1].setAreaSize(scanner.nextDouble());

            System.out.println("Please enter edit area population ");
            districts[id - 1].setAreaPopulation(scanner.nextLong());
            System.out.println(" The information of district edit successfully!");
        }else {
            System.out.println("Please try again!");
        }
    }

    @Override
    public void delete() {
        System.out.println("Which district you want to delete");
        //list
        getList();
        int id = scanner.nextInt();
        districts[id-1] = null;
        System.out.println("The district delete successfully!");
    }

    @Override
    public void getOne(String name) {
        boolean empty = true;
        for (int i = 0; i < districts.length; i++) {
            if (districts[i] != null && districts[i].getName().equalsIgnoreCase(name)) { //100%
                empty = false;
                System.out.println((i + 1) + " => " + districts[i]);
            }
        }
        if (empty) {
            System.out.println("There is not districts!");
        }

    }

    @Override
    public void getList() {
        System.out.println("The list of districts! ");
        boolean empty = true;
        for (int i = 0; i < districts.length; i++) {
            if (districts[i] != null) {
                empty = false;
                System.out.println((i + 1) + " => " + districts[i]);
            }
        }
        if (empty) {
            System.out.println("There is not districts!");
        }
    }
}
