package uz.pdp.RegionApp.Service;
import uz.pdp.RegionApp.model.Republic;
import java.util.Scanner;
public class RepublicImpl implements Service {
    static Republic[] republics = new Republic[5];
    Scanner scanner = new Scanner(System.in);
     @Override
    public void add() {
         Republic republic = new Republic();
         System.out.println("The list of adding republic : ");

         System.out.print("Please enter new District name : ");
         republic.setAreaName(scanner.nextLine());

         System.out.print("Please enter new District area size : ");
         republic.setAreaSize(scanner.nextDouble());

         System.out.print("Please enter new District area population : ");
         republic.setAreaPopulation(scanner.nextLong());

         for (int i = 0; i < republics.length; i++) {
             if (republics[i] == null) {
                 republics[i] = republic;
                 break;
             }
         }
         System.out.println("The district added successfully!");
    }

    @Override
    public void edit() {
        System.out.println("Which republic you want to change : ");
        //list
        int id = scanner.nextInt();
        if (republics.length >= id && republics[id - 1] != null) {
            System.out.println("Please enter edit name : ");
            republics[id - 1].setAreaName(scanner.nextLine());

            System.out.println("Please enter edit area size : ");
            republics[id - 1].setAreaSize(scanner.nextDouble());

            System.out.println("Please enter edit area population ");
            republics[id - 1].setAreaPopulation(scanner.nextLong());
            System.out.println(" The information of district edit successfully!");
        }else {
            System.out.println("Please try again!");
        }
    }

    @Override
    public void delete() {
        System.out.println("Which republic you want to delete");
        //list
        getList();
        int id = scanner.nextInt();
        republics[id-1] = null;
        System.out.println("The republic delete successfully!");
    }

    @Override
    public void getOne(String name) {
        boolean empty = true;
        for (int i = 0; i < republics.length; i++) {
            if (republics[i] != null && republics[i].getName().equalsIgnoreCase(name)) { //100%
                empty = false;
                System.out.println((i + 1) + " => " + republics[i]);
            }
        }
        if (empty) {
            System.out.println("There is not republic!");
        }
    }

    @Override
    public void getList() {
        System.out.println("The list of republic! ");
        boolean empty = true;
        for (int i = 0; i < republics.length; i++) {
            if (republics[i] != null) {
                empty = false;
                System.out.println((i + 1) + " => " + republics[i]);
            }
        }
        if (empty) {
            System.out.println("There is not republic!");
        }
    }

    @Override
    public String toString() {
        return "RepublicImpl{" +
                "scanner=" + scanner +
                '}';
    }
}
